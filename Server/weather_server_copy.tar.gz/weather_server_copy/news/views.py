from django.shortcuts import render
from news.models import *

# Create your views here.
from django.http import HttpResponse,JsonResponse


def news(request,location):
    location = location.split(',')[-1]
    tour = request.GET.get('tour')
    city = request.GET.get('city')
    weather = request.GET.get('weather')
    banner = request.GET.get('banner')
    traffic = request.GET.get('traffic')
    recommendation = request.GET.get('recommendation')

    if weather:
        if weather and banner:
            n_id = []
            title = []
            img_src = []
            weather_list = Weather.objects.filter(categoryid=location)
            for i in range(3):
                n_id.append(i)
                title.append(weather_list[i].title)
                img_src.append(weather_list[i].imgurl)
            data = {
                'n_id': n_id,
                'title': title,
                'img_src':img_src
            }
            return JsonResponse({
                'code': 200,
                'data': data,
                'img_src':img_src
            })
        n_id = []
        title = []
        weather_list = Weather.objects.filter(categoryid=location)
        for i in range(6):
            n_id.append(i)
            title.append(weather_list[i].title)
        data = {
            'n_id': n_id,
            'title': title
        }
        return JsonResponse({
            'code': 200,
            'data': data
        })

    if city:
        if tour and city:
            # categoryid: 国内新闻
            # message_list = News.objects.filter(categoryid=location)
            message_list = TjNews.objects.filter()
            print('*'*45)
            print(message_list)
            n_id = []
            title = []
            for i in range(6):
                n_id.append(i)
                title.append(message_list[i].title)
            data = {
                'n_id': n_id,
                'title': title
            }
            return JsonResponse({
                'code': 200,
                'data': data
            })
        n_id = []
        title = []
        # message_list = News.objects.filter(categoryid=location)
        message_list = News.objects.filter()
        for i in range(12):
            n_id.append(i)
            title.append(message_list[i].title)
        data = {
            'n_id': n_id,
            'title': title

        }
        return JsonResponse({
            'code': 200,
            'data': data
        })

    if tour:
        if tour and city:
            # message_list = News.objects.filter(categoryid=location)
            message_list = News.objects.filter()
            n_id = []
            title = []
            for i in range(6):
                n_id.append(i)
                title.append(message_list[i].title)
            data = {
                'n_id': n_id,
                'title': title
            }
            return JsonResponse({
                'code': 200,
                'data': data
            })
        n_id = []
        title = []
        message_list = News.objects.all()
        for i in range(6):
            n_id.append(i)
            title.append(message_list[i].title)
        data = {
            'n_id': n_id,
            'title': title
        }
        return JsonResponse({
            'code': 200,
            'data': data
        })

    if traffic:
        n_id = []
        title = []
        img_src = []
        # traffic_list = Traffic.objects.filter(categoryid=location)
        traffic_list = Traffic.objects.filter()
        for i in range(3):
            n_id.append(i)
            title.append(traffic_list[i].title)
            img_src.append(traffic_list[i].imgurl)
        data = {
            'n_id': n_id,
            'title': title,
            'img_src': img_src
        }
        return JsonResponse({
            'code': 200,
            'data': data,
            'img_src': img_src
        })


def news_detail(request):
    new_id = request.GET.get('new_id')
    data = {}
    if new_id:
        try:
            news = News.objects.get(id=new_id)
        except Exception as e:
            return JsonResponse({
                'code': 400,
                'data': '新闻不存在'
            })
        data['title'] = news.title
        data['categoryld'] = news.categoryid
        data['time'] = news.time
        data['source'] = news.source
        data['author'] = news.author
        data['tag'] = news.tag
        data['context'] = news.context
        return JsonResponse({
            'code': 200,
            'data': data
        })
