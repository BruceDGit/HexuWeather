from django.urls import path,include,re_path
import news.views as views
urlpatterns = [
    re_path(r'^detail$', views.news_detail),
    re_path(r'(?P<location>.*)', views.news),

]
