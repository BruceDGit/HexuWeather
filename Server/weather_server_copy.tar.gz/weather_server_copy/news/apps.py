from django.apps import AppConfig


class CityweatherConfig(AppConfig):
    name = 'news'
